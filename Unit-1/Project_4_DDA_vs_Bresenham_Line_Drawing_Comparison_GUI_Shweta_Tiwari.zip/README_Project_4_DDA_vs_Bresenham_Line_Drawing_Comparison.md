# Project 4: DDA vs Bresenham Line Drawing Comparison

**Faculty:** Shweta Tiwari
Assistant Professor
Department of Computer Science & Engineering (CSE)
Institute of Engineering & Technology, Lucknow (IET Lucknow)

## Project Type
Micro Mini Project – Computer Graphics

## Unit
Unit I – Scan Conversion / Line Drawing Algorithms

## Objective
To implement DDA and Bresenham line drawing algorithms and compare their rasterized pixels, algorithmic steps, and execution time.

## Technologies
- Python 3
- Matplotlib
- ipywidgets
- Jupyter Notebook / Google Colab

## Features
- Interactive GUI for line endpoints
- DDA line rasterization
- Bresenham line rasterization
- Side-by-side visualization
- Pixel count and execution-time comparison
- Ideal line reference
- Example and Clear buttons
- Viva questions and conclusion

## How to Run in Google Colab
1. Upload the `.ipynb` file to Google Colab.
2. Open the notebook.
3. Run the cells from top to bottom.
4. Enter X1, Y1, X2, Y2.
5. Click **Compare**.
6. Observe the DDA and Bresenham plots and comparison values.

## Sample Test Case
Input: `(2,2) → (12,8)`

Expected DDA values:
- dx = 10
- dy = 6
- steps = 10
- x increment = 1.0
- y increment = 0.6

Both algorithms generate a raster approximation of the same ideal line.

## Learning Outcomes
Students learn:
- Line scan conversion
- Floating-point incremental line generation
- Integer error-based line generation
- Raster pixel selection
- Algorithm comparison and visualization

## Result
The project demonstrates the working and practical difference between DDA and Bresenham line drawing algorithms through an interactive graphical comparison.

## Faculty Reference
Shweta Tiwari
Assistant Professor
Department of Computer Science & Engineering (CSE)
Institute of Engineering & Technology, Lucknow (IET Lucknow)
