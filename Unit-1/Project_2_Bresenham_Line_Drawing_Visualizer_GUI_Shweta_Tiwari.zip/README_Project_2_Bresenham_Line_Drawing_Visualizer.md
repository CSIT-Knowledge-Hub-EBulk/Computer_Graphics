# Bresenham Line Drawing Visualizer
## Computer Graphics – Micro Mini Project

**Prepared by:** Shweta Tiwari  
Assistant Professor  
Department of Computer Science & Engineering (CSE)  
Institute of Engineering & Technology, Lucknow (IET Lucknow)

## Project Description
Interactive GUI implementation of the Bresenham Line Drawing Algorithm for Google Colab/Jupyter.

## Objectives
- Understand raster line drawing.
- Implement Bresenham's algorithm.
- Visualize integer-based pixel selection.
- Compare raster pixels with the ideal line.

## Technology
Python, Matplotlib, ipywidgets, Google Colab/Jupyter Notebook.

## How to Run
1. Open Google Colab.
2. Select **File → Upload notebook**.
3. Upload the project `.ipynb`.
4. Select **Runtime → Run all**.
5. Enter X1, Y1, X2, Y2 and click **Draw Line**.
6. Click **Example** for a ready-made test case.

## Sample Test Case
Starting point: `(2,2)`  
Ending point: `(12,8)`

The GUI displays `dx`, `dy`, generated pixels, the ideal line, and raster pixels.

## Learning Outcomes
Students learn Bresenham's decision parameter, integer-based rasterization, pixel selection, and the practical difference between DDA and Bresenham.

## Viva Questions
1. What is Bresenham's line drawing algorithm?
2. Why is it efficient?
3. What is the decision parameter?
4. Why are integer operations preferred?
5. How does Bresenham differ from DDA?

## Result
The project successfully visualizes a line using Bresenham's integer-based rasterization technique.

## Faculty / Project Reference
**Shweta Tiwari**  
Assistant Professor  
Department of Computer Science & Engineering (CSE)  
Institute of Engineering & Technology, Lucknow (IET Lucknow)
