# Project 6: Circle Pattern Generator

**Faculty:** Shweta Tiwari
Assistant Professor
Department of Computer Science & Engineering (CSE)
Institute of Engineering & Technology, Lucknow (IET Lucknow)

## Project Type
Micro Mini Project – Computer Graphics

## Unit
Unit I – Basic 2D Graphics / Circle Drawing

## Objective
To generate symmetric 2D circular patterns by placing multiple circles around a common center using parameterized coordinates and an interactive GUI.

## Technologies
- Python 3
- Matplotlib
- ipywidgets
- Jupyter Notebook / Google Colab

## Features
- Adjustable number of circles
- Adjustable orbit radius
- Adjustable circle radius
- Adjustable rotation angle
- Optional orbit display
- Optional center circle
- Interactive GUI
- Symmetric geometric pattern generation
- Example and Clear buttons

## How to Run in Google Colab
1. Upload the `.ipynb` file to Google Colab.
2. Run all cells from top to bottom.
3. Adjust the GUI parameters.
4. Click **Generate Pattern**.
5. Use **Example** for a ready-made configuration.

## Core Formula
For a circle center placed on an orbit:

`cx = R cos(theta)`

`cy = R sin(theta)`

where `R` is the orbit radius and `theta` is the angular position.

For `n` circles, angular separation is:

`360 / n` degrees.

## Sample Test Case
12 circles, orbit radius 10, circle radius 3, rotation 0°.

Angular separation = `30°`.

## Learning Outcomes
Students learn:
- Parametric circle representation
- Trigonometric coordinate generation
- Rotational symmetry
- Repeated graphics primitives
- Interactive visualization

## Result
The project successfully generates parameterized and symmetric circle patterns using Python and Matplotlib.

## Faculty Reference
Shweta Tiwari
Assistant Professor
Department of Computer Science & Engineering (CSE)
Institute of Engineering & Technology, Lucknow (IET Lucknow)
