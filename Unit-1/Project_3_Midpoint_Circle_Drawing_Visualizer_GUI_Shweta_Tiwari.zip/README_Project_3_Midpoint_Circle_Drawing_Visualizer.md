# Midpoint Circle Drawing Visualizer
## Computer Graphics – Micro Mini Project

**Prepared by:** Shweta Tiwari  
Assistant Professor  
Department of Computer Science & Engineering (CSE)  
Institute of Engineering & Technology, Lucknow (IET Lucknow)

## Project Description
This micro mini-project implements and visualizes the Midpoint Circle Drawing Algorithm using an interactive GUI in Google Colab/Jupyter.

## Objectives
- Understand raster circle drawing.
- Implement the Midpoint Circle Drawing Algorithm.
- Understand eight-way symmetry.
- Visualize generated pixels against an ideal circle.

## Technology Used
- Python
- Matplotlib
- ipywidgets
- Google Colab / Jupyter Notebook

## How to Run
1. Open Google Colab.
2. Select **File → Upload notebook**.
3. Upload `Project_3_Midpoint_Circle_Drawing_Visualizer_GUI_Shweta_Tiwari.ipynb`.
4. Select **Runtime → Run all**.
5. Enter center X, center Y, and radius.
6. Click **Draw Circle** or **Example**.

## Sample Test Case
Center: `(0,0)`  
Radius: `8`

The GUI displays the ideal circle, generated pixels, center, radius, and number of pixels plotted.

## Learning Outcomes
Students learn circle rasterization, decision parameters, eight-way symmetry, and graphical visualization.

## Viva Questions
1. What is the Midpoint Circle Drawing Algorithm?
2. Why is circle symmetry used?
3. What is the initial decision parameter?
4. How many symmetric points can be generated from one point?
5. Why is the algorithm suitable for raster graphics?

## Result
The project successfully demonstrates raster circle generation using an efficient decision-parameter and symmetry-based approach.

## Faculty / Project Reference
**Shweta Tiwari**  
Assistant Professor  
Department of Computer Science & Engineering (CSE)  
Institute of Engineering & Technology, Lucknow (IET Lucknow)
