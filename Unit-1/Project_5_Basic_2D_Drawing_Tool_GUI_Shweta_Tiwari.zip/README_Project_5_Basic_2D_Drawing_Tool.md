# Project 5: Basic 2D Drawing Tool

**Faculty:** Shweta Tiwari
Assistant Professor
Department of Computer Science & Engineering (CSE)
Institute of Engineering & Technology, Lucknow (IET Lucknow)

## Project Type
Micro Mini Project – Computer Graphics

## Unit
Unit I – Basic 2D Graphics

## Objective
To develop a simple interactive 2D drawing tool for drawing points, lines, rectangles, circles, and triangles using coordinate-based input.

## Technologies
- Python 3
- Matplotlib
- ipywidgets
- Jupyter Notebook / Google Colab

## Features
- Point drawing
- Line drawing
- Rectangle drawing
- Circle drawing
- Triangle drawing
- Interactive GUI
- Coordinate input
- Example and Clear buttons
- Cartesian grid and equal scaling

## How to Run in Google Colab
1. Upload the `.ipynb` file to Google Colab.
2. Run all cells from top to bottom.
3. Select a primitive from the Shape dropdown.
4. Enter its coordinates/parameters.
5. Click **Draw**.
6. Use **Example** for a ready-made test and **Clear** to reset the output.

## Sample Test Cases
- Point: `(5,6)`
- Line: `(-8,-5) → (10,8)`
- Rectangle: bottom-left `(-8,-5)`, width `12`, height `8`
- Circle: center `(2,3)`, radius `7`
- Triangle: `(-8,-6)`, `(8,-6)`, `(0,8)`

## Learning Outcomes
Students learn:
- 2D coordinate representation
- Basic graphics primitives
- Interactive graphical input
- Matplotlib drawing objects
- Foundation of simple graphics editors

## Result
The project successfully demonstrates an interactive basic 2D drawing tool using Python.

## Faculty Reference
Shweta Tiwari
Assistant Professor
Department of Computer Science & Engineering (CSE)
Institute of Engineering & Technology, Lucknow (IET Lucknow)
